#include<iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
using namespace std;

#define _BUG_ printf("---------bug--------\n")
#define LL long long
#define RG register int
const int N=100010;
#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
using namespace std;

#define OK 1
#define ERROR 0
typedef int Status;
#define MAXVNUM 1000
int XX;
bool vis[MAXVNUM];
bool DFSF=1;
int adjmatrix[MAXVNUM][MAXVNUM];
struct Edge{
    int adjvex;
    Edge * Next;
    int w;
    
};
template<class Elemtype>
struct Node{
    bool del;
    int cnt;
    Elemtype NodeName;
    Edge *fst;
    int indegree;//入度
};
template<class Elemtype>
class AlGragh{
public:
    string Type;
    Elemtype topuOder[MAXVNUM];
    int u[MAXVNUM];
    int v[MAXVNUM];
    int w[MAXVNUM];
    Node<Elemtype> Gr[MAXVNUM];
    int n;//顶点数
    int m;//边数
    int dn;
    void add_edge(int u,int v,int w=0);
    void show();
    void init(string type);
    void del_node(int i);
    void DFS(int i);
    void BFS(int i);
    int * getIndegree();
    Status TopologicalSort(int &num);
    void Dijkstra(int u, int*dist, int *pre); 
};


struct node{
    LL dis;
    int u;
    bool operator <(const node &x)const{
        return x.dis<dis;
    }
};
priority_queue<node>q;

template<class Elemtype>
void AlGragh<Elemtype>::Dijkstra(int u, int *dist, int *pre){
    
    for(int i=0;i<n;++i){dist[i]=100000;}
    dist[u]=0;
    pre[u]=-1;
    
    q.push((node){0,u});
    while(!q.empty()){
        node tmp=q.top();q.pop();
        int u=tmp.u;
        if(vis[u])continue;
        vis[u]=1;
        Edge *e=Gr[u].fst;
        while(e!=NULL){
            int v=e->adjvex;
            if(dist[v]>dist[u]+e->w){
                dist[v]=dist[u]+e->w;
                pre[v]=u;
                if(!vis[v]) q.push((node){dist[v],v});
            }
            e=e->Next;
        }
    }

}
template<class Elemtype>
Status AlGragh<Elemtype>::TopologicalSort(int &num){
    int* indegree=new int[MAXVNUM];
    indegree=getIndegree();
    queue<int>St;
    for(int i=0;i<n;++i){
        if(indegree[i]==0){
            St.push(i);
        }
    }
    int cnt=0;//参与topu排序的点的个数
    while(St.size()){
        int u=St.front();St.pop();
        topuOder[cnt++]=Gr[u].NodeName;
        vis[u]=1;
        Edge *P=Gr[u].fst;
        while(P){
            int v=P->adjvex;
            indegree[v]--;
            if(!indegree[v]&&!vis[v])St.push(v);
            P=P->Next;
        }
    }
    num=cnt;
    if(cnt==n)return OK;
    else return ERROR;
}
template<class Elemtype>
int * AlGragh<Elemtype>::getIndegree(){
    int *Ans=new int[MAXVNUM];
    for(int i=0;i<n;++i){
        Ans[i]=Gr[i].indegree;
    }
    return Ans;
}

template<class Elemtype>
void AlGragh<Elemtype>::BFS(int i){
    queue<int>Q;
    Q.push(i);
    while(Q.size()){
        int now = Q.front();Q.pop();
        if(vis[now])continue;
        if(DFSF){
            DFSF=0;
            cout<<"V"<<now+1;
        }
        else cout<<"->V"<<now+1;
        vis[now]=1;
        Edge *e=Gr[now].fst;
        while(e!=NULL){
            int v=e->adjvex;
            if(vis[v]==0){
                Q.push(v);
            }
            e=e->Next;
        }
    }
    
}
template<class Elemtype>
void AlGragh<Elemtype>::DFS(int i){
    vis[i]=1;
    if(DFSF){
        DFSF=0;
        cout<<"V"<<i+1;
    }
    else cout<<"->V"<<i+1;
    Edge *e=Gr[i].fst;
    while(e!=NULL){
        int v=e->adjvex;
        if(!vis[v]){
            DFS(v);
        }
        e=e->Next;
    }
}
template<class Elemtype>
void AlGragh<Elemtype>::del_node(int i){
    dn++;
    Gr[i].del=1;
    if(Type=="UDG"){
        m-=Gr[i].cnt;
    }
    else m-=Gr[i].cnt;
    for(int j=0;j<n;++j){
        if(j==i)continue;
        Edge *P=Gr[j].fst,*pre=NULL;
        while(P!=NULL){
            if(P->adjvex==i){
                if(Type=="DG")m--;
                if(pre==NULL){Gr[j].fst=NULL;break;}
                else pre->Next=P->Next;
            }
            else if(P->adjvex>i){
                P->adjvex--;
                pre=P;
            }
            else{
                pre=P;
            }
            P=P->Next;
        }
    }
    n--;
}
template<class Elemtype>
void AlGragh<Elemtype>::show(){
    bool fst=1;
    for(int i=0;i<n+dn;++i){
        if(Gr[i].del)continue;
        if(fst){fst=0;cout<<Gr[i].NodeName;}
        else cout<<" "<<Gr[i].NodeName;       
    }

    cout<<endl;
    cout<<endl;


    for(int i=0;i<n+dn;++i){
        if(Gr[i].del)continue;
        cout<<Gr[i].NodeName;
        Edge *P=Gr[i].fst;
        while(P!=NULL){
            cout<<"->"<<P->adjvex;
            if(Type=="DN")cout<<"("<<P->w<<")";
            P=P->Next;
        }
        cout<<endl;
    }
}
template<class Elemtype>
void AlGragh<Elemtype>:: add_edge(int u,int v,int w){
    Edge *E=new Edge,*P;
    E->adjvex=v;
    E->w=w;
    Gr[v].indegree++;
    P=Gr[u].fst;
    Gr[u].fst=E;
    E->Next=P; 
}
template<class Elemtype>
void AlGragh<Elemtype>::init(string type){
    Type=type;
    dn=0;
    cin>>n;
    for(int i=0;i<n;++i){
        Elemtype ch;
        cin>>ch;
        Gr[i].NodeName=ch;
        Gr[i].del=0;
        Gr[i].fst=NULL;
        Gr[i].cnt=0;
        Gr[i].indegree=0;
    }
    cin>>XX;
    cin>>m;
    for(int i=0;i<m;++i){
        cin>>u[i]>>v[i];
    }
    if(Type=="DN"){
        for(int i=0;i<m;++i)cin>>w[i];
    }
    if(Type=="DN"){
        for(int i=0;i<n;++i){
            for(int j=0;j<n;++j){
                adjmatrix[i][j]=XX;
            }
        }
    }
    else{
        for(int i=0;i<n;++i){
            for(int j=0;j<n;++j){
                adjmatrix[i][j]=0;
            }
        }
    }
    for(int i=0;i<m;++i){
        if(Type=="DG"){
            add_edge(u[i],v[i]);
            adjmatrix[u[i]][v[i]]=1;
            Gr[u[i]].cnt++;
        }
        else{
            add_edge(u[i],v[i],w[i]);
            
            adjmatrix[u[i]][v[i]]=w[i];
            Gr[u[i]].cnt++;
        }
    }
}
stack<int>st;
template<class T>
void searchPath(int u,int bg,int *pre,AlGragh<T>AG){
    int now=u;
    while(now!=bg){
        st.push(now);
        now=pre[now];
    }
    st.push(bg);
    bool fst=1;
    cout<<"<";
    while(!st.empty()){
        int v=st.top();st.pop();
        if(fst){cout<<"("<<v<<","<<AG.Gr[v].NodeName<<")";fst=0;}
        else{
            cout<<",("<<v<<","<<AG.Gr[v].NodeName<<")";
        }
    }
    cout<<">,";
}




int main()
{
    AlGragh<string> AG;
    string type;
    cin>>type;
    AG.init(type);
    int bg;
    cin>>bg;
    Edge *P=AG.Gr[bg].fst;
    
    int pre[1001];
    int dis[1001];
    for(int i=0;i<AG.n;++i){
        dis[i]=1000000;
    }
    dis[bg]=0;
    if(P!=NULL){
        int v=P->adjvex;
        pre[v]=bg+1;
        dis[v]=P->w;
    }
    bool fst=1;
    for(int i=0;i<AG.n;++i){
        if(AG.Gr[i].del)continue;
        if(fst){fst=0;cout<<AG.Gr[i].NodeName;}
        else cout<<" "<<AG.Gr[i].NodeName;       
    }
    cout<<endl<<endl;

    for(int i=0;i<AG.n;++i){
        for(int j=0;j<AG.n;++j){
            cout<<adjmatrix[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;

    for(int i=0;i<AG.n;++i){
        if(i==bg){
            cout<<"0 ";
        }
        else cout<<adjmatrix[bg][i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<AG.n;++i){
        if(adjmatrix[bg][i]!=XX){
            cout<<bg+1<<" ";
        }
        else cout<<"0 ";
    }
    cout<<endl;
    AG.Dijkstra(bg,dis,pre);
    cout<<endl;

    for(int i=0;i<AG.n;++i){
        if(dis[i]==1000000)cout<<XX<<" ";
        else cout<<dis[i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<AG.n;++i){
        cout<<pre[i]+1<<" ";
    }
    cout<<endl;
    cout<<endl;


    for(int i=0;i<AG.n;++i){
        if(i==bg)continue;
        searchPath(i,bg,pre,AG);
        cout<<dis[i];
        cout<<endl;
    }

    return 0;
}
