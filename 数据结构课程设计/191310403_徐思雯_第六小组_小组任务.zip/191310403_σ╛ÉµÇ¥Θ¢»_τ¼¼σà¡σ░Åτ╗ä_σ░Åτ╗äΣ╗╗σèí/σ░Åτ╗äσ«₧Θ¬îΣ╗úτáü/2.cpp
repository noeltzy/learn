#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
using namespace std;

#define OK 1
#define ERROR 0
typedef int Status;
#define MAXVNUM 1000
#define _BUG_ puts("\n!!!");


bool vis[MAXVNUM];
bool DFSF=1;
struct Edge{
    int adjvex;
    Edge * Next;
    int w;
    
};
template<class Elemtype>
struct Node{
    bool del;
    int cnt;
    Elemtype NodeName;
    Edge *fst;
    int indegree;//入度
};

template<class Elemtype>
class AlGragh{
public:
    string Type;//DG（有向图）, DN（有向网）, UDG（无向图）, UDN（无向网
    Elemtype topuOder[MAXVNUM];//图的拓扑序
    int u[MAXVNUM];
    int v[MAXVNUM];
    int w[MAXVNUM];
    Node<Elemtype> Gr[MAXVNUM];//邻接表
    int n;//顶点数
    int m;//边数
    int dn;//删除定点标记
    void add_edge(int u,int v,int w=0);//添加边
    void show();//根据题目自己写
    void showNode();//输出结点
    void showEdge();//输出邻接表
    void init(string type);//根据type建图
    void del_node(int i);//删除结点
    void DFS(int i);
    void BFS(int i);
    void add(int u,int v,int w=0);
    int * getIndegree();
    Status TopologicalSort(int &num);
    int LocateVer(Elemtype NodeName);//返回NodeName结点下标编号
    bool Insert_Edge(int u, int v,int w=0); //无权图插入一条边
    bool haveEdge(int u,int v);
};
int a[1000];
int cnt;
void dfs(int cur,int u,int len,AlGragh<char> G){
    a[cur]=u;
    if(cur==len){
        cnt++;
        bool fst=1;
        for(int i=1;i<=len;++i){
            if(fst){cout<<G.Gr[a[i]].NodeName;fst=0;}
            else cout<<"->"<<G.Gr[a[i]].NodeName;
        }
        cout<<endl;
        return;
    }
    Edge *P=G.Gr[u].fst;
    while(P){
        int v=P->adjvex;
        dfs(cur+1,v,len,G);
        P=P->Next;
    }
    return;
}
//这里是主函数
int main(){
    AlGragh<char> G;
    //!!这里是主函数  
    string Type;
    cin>>Type;
    G.init(Type);
    int  bg;
    cin>>bg;
    int len;
    cin>>len;
    G.show();
    dfs(1,bg,len+1,G);
    cout<<cnt<<endl;
}
template<class Elemtype>
bool AlGragh<Elemtype>::haveEdge(int from,int to){
    for(int i=0;i<m;++i){
        if(u[i]==from&&v[i]==to)return 1;
        if(u[i]==to&&v[i]==from)return 1;
    }
    return 0;
}

template<class Elemtype>
bool AlGragh<Elemtype>::Insert_Edge(int u,int v,int w){
    if(u<0||u>=n||v<0||v>=n)return false;
    if(haveEdge(u,v)) return false;
    m++;
    add_edge(u,v,w);
    return true;
}


template<class Elemtype>
void AlGragh<Elemtype>::show(){
    showNode();
    showEdge();
    cout<<endl;
}

template<class Elemtype>
int AlGragh<Elemtype>::LocateVer(Elemtype NodeName){
    int index=-1;
    for(int i=0;i<n;++i){
        if(Gr[i].NodeName==NodeName){
            index=i;
            break;
        }
    }
    return index;
}

template<class Elemtype>
void AlGragh<Elemtype>::del_node(int i){
    dn++;
    Gr[i].del=1;
    if(Type=="UDG"){
        m-=Gr[i].cnt;
    }
    else m-=Gr[i].cnt;
    for(int j=0;j<n;++j){
        if(j==i)continue;
        Edge *P=Gr[j].fst,*pre=NULL;
        while(P!=NULL){
            if(P->adjvex==i){
                if(Type=="DG")m--;
                if(pre==NULL){Gr[j].fst=NULL;break;}
                else pre->Next=P->Next;
            }
            else if(P->adjvex>i){
                P->adjvex--;
                pre=P;
            }
            else{
                pre=P;
            }
            P=P->Next;
        }
    }
    n--;
}
template<class Elemtype>
Status AlGragh<Elemtype>::TopologicalSort(int &num){
    int* indegree=new int[MAXVNUM];
    indegree=getIndegree();
    queue<int>St;
    for(int i=0;i<n;++i){
        if(indegree[i]==0){
            St.push(i);
        }
    }
    int cnt=0;//参与topu排序的点的个数

    while(St.size()){
        int u=St.front();St.pop();
        topuOder[cnt++]=Gr[u].NodeName;
        vis[u]=1;
        Edge *P=Gr[u].fst;
        while(P){
            int v=P->adjvex;
            indegree[v]--;
            if(!indegree[v]&&!vis[v])St.push(v);
            P=P->Next;
        }
    }
    num=cnt;
    if(cnt==n)return OK;
    else return ERROR;

}
template<class Elemtype>
int * AlGragh<Elemtype>::getIndegree(){
    int *Ans=new int[MAXVNUM];
    for(int i=0;i<n;++i){
        Ans[i]=Gr[i].indegree;
    }
    return Ans;
}
template<class Elemtype>
void AlGragh<Elemtype>::DFS(int i){
    vis[i]=1;
    if(DFSF){
        DFSF=0;
        cout<<"V"<<i+1;
    }
    else cout<<"->V"<<i+1;
    Edge *e=Gr[i].fst;
    while(e!=NULL){
        int v=e->adjvex;
        if(!vis[v]){
            DFS(v);
        }
        e=e->Next;
    }
}
template<class Elemtype>
void AlGragh<Elemtype>::add_edge(int u,int v,int w){
    if(Type=="DG"){
        add(u,v);
    }
    else if(Type=="UDG"){
        add(u,v);
        add(v,u);
    }
    else if(Type=="DN"){
        add(u,v,w);
    }
    else if(Type=="UDN"){
        add(u,v,w);
        add(v,u,w);
    }
    
}
template<class Elemtype>
void AlGragh<Elemtype>:: add(int u,int v,int w){
    Edge *E=new Edge,*P;
    E->adjvex=v;
    E->w=w;
    Gr[v].indegree++;
    P=Gr[u].fst;
    Gr[u].fst=E;
    E->Next=P;
    Gr[u].cnt++;
}


template<class Elemtype>
void AlGragh<Elemtype>::init(string type){
    Type=type;
    dn=0;
    cin>>n;
    for(int i=0;i<n;++i){
        Elemtype ch;
        cin>>ch;
        Gr[i].NodeName=ch;
        Gr[i].del=0;
        Gr[i].fst=NULL;
        Gr[i].cnt=0;
        Gr[i].indegree=0;
    }
    cin>>m;
    for(int i=0;i<m;++i){
        cin>>u[i]>>v[i];
        w[i]=0;
    }
    if(Type=="DN"||Type=="UDN"){
        for(int i=0;i<m;++i)cin>>w[i];
    }
    for(int i=0;i<m;++i){
        add_edge(u[i],v[i],w[i]);
    }
}
template<class Elemtype>
void AlGragh<Elemtype>::showNode(){
    bool fst=1;
    for(int i=0;i<n+dn;++i){
        if(Gr[i].del)continue;
        if(fst){fst=0;cout<<Gr[i].NodeName;}
        else cout<<" "<<Gr[i].NodeName;       
    }
    cout<<endl;
}
template<class Elemtype>
void AlGragh<Elemtype>::showEdge(){
    for(int i=0;i<n+dn;++i){
        if(Gr[i].del)continue;
        cout<<Gr[i].NodeName;
        Edge *P=Gr[i].fst;
        while(P!=NULL){
            cout<<"->"<<P->adjvex;
            if(Type=="DN"||Type=="UDN")cout<<"("<<P->w<<")";
            P=P->Next;
        }
        cout<<endl;
    }
}
template<class Elemtype>
void AlGragh<Elemtype>::BFS(int i){
    queue<int>Q;
    Q.push(i);
    while(Q.size()){
        int now = Q.front();Q.pop();
        if(vis[now])continue;
        if(DFSF){
            DFSF=0;
            cout<<"V"<<now+1;
        }
        else cout<<"->V"<<now+1;
        vis[now]=1;
        Edge *e=Gr[now].fst;


        while(e!=NULL){
            int v=e->adjvex;
            if(vis[v]==0){
                Q.push(v);
            }
            e=e->Next;
        }
    }
    
}