#include<bits/stdc++.h>
using namespace std;
#define MaxInt 32767
#define MVNum 100
#define OK 1
#define ERROR 0
typedef int Status;
typedef char VerTexType;
typedef double ArcType;
typedef struct
{
    VerTexType vexs[MVNum];
    ArcType arcs[MVNum][MVNum];
    int vexnum,arcnum;
    string type;
}AMGraph;
struct
{
    VerTexType adjvex;
    ArcType lowcost;
}closedge[MVNum];
Status Create(AMGraph &G)
{
    cin>>G.type>>G.vexnum;
    for(int i=0;i<G.vexnum;i++)
        cin>>G.vexs[i];
    double sign;
    cin>>sign;
    for(int i=0;i<G.vexnum;i++)
        for(int j=0;j<G.vexnum;j++)
            G.arcs[i][j]=sign;
    cin>>G.arcnum;
    int a[MVNum],b[MVNum];
     double size[MVNum];
    for(int i=0;i<G.arcnum;i++)
        cin>>a[i]>>b[i];
    for(int i=0;i<G.arcnum;i++)
        cin>>size[i];
    if(G.type=="DG"||G.type=="DN")
    {
        for(int i=0;i<G.arcnum;i++)
        G.arcs[a[i]][b[i]]=size[i];
    }
    else if(G.type=="UDG"||G.type=="UDN")
    {
        for(int i=0;i<G.arcnum;i++)
        {G.arcs[a[i]][b[i]]=size[i];
        G.arcs[b[i]][a[i]]=size[i];}
    }
    return OK;
}
int LocateVer(AMGraph &G,VerTexType u)
{
    for(int i=0;i<G.vexnum;i++)
        if(G.vexs[i]==u)
        return i;
    return -1;
}
void MiniSpanTree_Prim(AMGraph G,int u,double& sum)
{
    int v=u;
    for(int j=0;j<G.vexnum;j++)
        if(j!=v)
    {
        closedge[j].adjvex=G.vexs[u];
        closedge[j].lowcost=G.arcs[v][j];
    }
    closedge[v].lowcost=0;
    double min[G.vexnum];
    for(int i=0;i<G.vexnum;i++)
        min[i]=9999;
    for(int i=1;i<G.vexnum;i++)
    {
        int k=-1;
        for(int j=0;j<G.vexnum;j++)
            if(closedge[j].lowcost!=0&&closedge[j].lowcost<min[i])
        {
            min[i]=closedge[j].lowcost;
            k=j;
        }
        closedge[k].lowcost=0;
        for(int j=0;j<G.vexnum;j++)
            if(G.arcs[k][j]<closedge[j].lowcost)
            {
        closedge[j].adjvex=G.vexs[k];
        closedge[j].lowcost=G.arcs[k][j];
    }
    }
    for(int i=0;i<G.vexnum;i++)
    {
        if(i==u)  continue;
        else
       {
        int u0=LocateVer(G,closedge[i].adjvex);
        sum+=G.arcs[i][u0];
       }
    }
}
int main()
{
    AMGraph G;
    Create(G);
    int start;
    cin>>start;
    double distance;
    cin>>distance;
    double sum=0;
    MiniSpanTree_Prim(G,start,sum);
    cout<<distance+sum;
    return 0;
}