#include<iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;

#define _BUG_ printf("---------bug--------\n")
#define LL long long
#define RG register int
#define MAXSIZE 1000
#define OK 1
#define ERROR 0 
typedef int Status;

template<class ElemType>
class SqQueue{
private:
    ElemType *Base;
    int Front;
    int rear;
public:
    Status init(){
        Base=new ElemType[MAXSIZE];
        Front=rear=0;
        if(Base==NULL)return ERROR;
        else return OK;
    }
    bool empty(){
        return Front==rear;
    }
    bool full(){
        return (rear+1)%MAXSIZE==Front;
    }
    int lenth(){
        return (rear-Front+MAXSIZE)%MAXSIZE;
    }
    Status push(ElemType e){
        if(full())return ERROR;
        Base[rear]=e;
        rear=(rear+1)%MAXSIZE;
        return OK;
    }
    ElemType front(){
        if(!empty())return Base[Front];
    }
    Status pop(ElemType &e){
        if(empty())return ERROR;
        e=Base[Front];
        Front=(Front+1)%MAXSIZE;
        return OK;
    }

};

struct node
{
    int id;
    int data;
};
bool cmp(node a,node b){
    return a.data<b.data;
}

template<class ElemType>
void Schedule(vector<ElemType> &A, SqQueue<int> &system_task, SqQueue<int> &user_task){
    vector<node> B;
    for(int i=0;i<A.size();++i){
        node tmp;
        tmp.id=A[i].id;
        tmp.data=A[i].data;
        B.push_back(tmp);
    }
    sort(B.begin(),B.end(),cmp);

    for(int i=0;i<B.size();++i){
        if(B[i].data<50){
            system_task.push(B[i].id);
        }
        else if(B[i].data<=255){
            user_task.push(B[i].id);
        }
    }
}

int main(){
    int num;
    int  cnt=0;
    vector<node>v;
    while(cin>>num){
        node i;
        i.id=cnt++;
        i.data=num;
        v.push_back(i);
    }
    SqQueue<int>system_task,user_task;
    
    system_task.init();
    user_task.init();

    Schedule(v,system_task,user_task);

    int len=v.size();
    bool fst=1;
    for(int i=0;i<len;++i){
        if(fst){
            fst=0;
            cout<<"("<<i<<","<<v[i].data<<")";
        }
        else{
            cout<<",("<<i<<","<<v[i].data<<")";
        }
    }
    cout<<endl;
    cout<<endl;
    if(system_task.lenth()==0){
        cout<<"none\n";
    }
    else{
        int e;
        while(!system_task.empty()){
            system_task.pop(e);
            cout<<e<<" ";
        }
        cout<<"\n";
    }
    if(user_task.lenth()==0){
        cout<<"none\n";
    }
    else{
        int e;
        while(!user_task.empty()){
            user_task.pop(e);
            cout<<e<<" ";
        }
        cout<<"\n";
    }
}