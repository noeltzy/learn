#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>

using namespace std;

int fa[10020];
int Find(int x){
    if(fa[x]==x)return x;
    else return fa[x]=Find(fa[x]);
}

template<class T>
struct E{
    int u,v;
    T w;
    bool is;
    int id;
};
template<class ElemType>
int Partition(vector<ElemType> &A, vector<int> &B,int low, int high)
{
    ElemType tmp1;
    int tmp2;
    tmp1=A[low];
    tmp2=B[low];
    ElemType pivotkey=A[low];
    while(low<high)
    {
        while(low<high&&A[high]>=pivotkey)
            high--;
        A[low]=A[high];
        B[low]=B[high];
        while(low<high&&A[low]<=pivotkey)
            low++;
        A[high]=A[low];
        B[high]=B[low];
    }
    A[low]=tmp1;
    B[low]=tmp2;
    return low;
}
template<class ElemType>
void Qsort(vector<ElemType> &A, vector<int> &B,int low, int high)
{
    if(low<high)
    {
        int pivotloc=Partition(A,B,low,high);
        Qsort(A,B,low,pivotloc-1);
        Qsort(A,B,pivotloc+1,high);
    }
}
template<class ElemType>
void QuickSort(vector<ElemType> &A,vector<int> &B)
{
    int tmp=A.size()-1;
    Qsort(A,B,0,tmp);
}



template<class T>
bool cmp(E<T> a,E<T> b){
    return a.w<b.w;
}
template<class T>
T Kruskal(int cnt,int n,E<T>*edge){
    sort(edge,edge+cnt,cmp<T>);

    T Ans=0;
    for(int i=0;i<n;++i) fa[i]=i;
    for(int i=0;i<cnt;++i){
        int u=edge[i].u;
        int v=edge[i].v;
        T w=edge[i].w;
        if(Find(u)!=Find(v)){
            Ans+=w;
            fa[Find(u)]=Find(v);
            edge[i].is=1;
        }
    }
    return Ans;
}
int main(){
    int op;
    cin>>op;
    string s;
    cin>>s;
    cout<<s<<endl;
    string nodeName[1001];
    int n,m;
    
    if(op==0){
        
        vector<int>A;
        vector<int>B;
        E<int> edge[1001];
        cin>>n;
        for(int i=0;i<n;++i){
            cin>>nodeName[i];
        }
        cin>>m;
        int u,v;
        for(int i=0;i<m;++i){
            cin>>u>>v;
            edge[i].u=u;
            edge[i].v=v;
            edge[i].id=i;
            edge[i].is=0;
        }
        for(int i=0;i<m;++i){
            cin>>edge[i].w;
            B.push_back(i);
            A.push_back(edge[i].w);
        }
        for(int i=0;i<m;++i){
            cout<<edge[i].w<<" ";
        }
        cout<<endl;
        for(int i=0;i<m;++i){
            cout<<edge[i].id<<" ";
        }
        cout<<endl;
        cout<<endl;

        int Ans=Kruskal(m, n, edge);
        QuickSort(A,B);


        for(int i=0;i<m;++i){
            cout<<A[i]<<" ";
        }
        cout<<endl;
        for(int i=0;i<m;++i){
            cout<<B[i]<<" ";
        }

        cout<<endl<<endl;

        for(int i=0;i<m;++i){
            if(edge[i].is){
                cout<<"("<<nodeName[edge[i].u]<<","<<nodeName[edge[i].v]<<"),"<<edge[i].w<<endl;
                // printf("(%d,%d),%d\n",edge[i].u,edge[i].v,edge[i].w);
            }
        }
        cout<<endl;
        cout<<Ans;
    }
    else if(op==1){
        vector<double>A;
        vector<int>B;
        E<double> edge[1001];
        cin>>n;
        for(int i=0;i<n;++i){
            cin>>nodeName[i];
        }
        cin>>m;
        int u,v;
        for(int i=0;i<m;++i){
            cin>>u>>v;
            edge[i].u=u;
            edge[i].v=v;
            edge[i].id=i;
            edge[i].is=0;
        }
        for(int i=0;i<m;++i){
            cin>>edge[i].w;
            B.push_back(i);
            A.push_back(edge[i].w);
        }
        for(int i=0;i<m;++i){
            cout<<edge[i].w<<" ";
        }
        cout<<endl;
        for(int i=0;i<m;++i){
            cout<<edge[i].id<<" ";
        }
        cout<<endl;
        cout<<endl;

        double Ans=Kruskal(m, n, edge);
        QuickSort(A,B);


        for(int i=0;i<m;++i){
            cout<<A[i]<<" ";
        }
        cout<<endl;
        for(int i=0;i<m;++i){
            cout<<B[i]<<" ";
        }

        cout<<endl<<endl;

        for(int i=0;i<m;++i){
            if(edge[i].is){
                cout<<"("<<nodeName[edge[i].u]<<","<<nodeName[edge[i].v]<<"),"<<edge[i].w<<endl;
                // printf("(%d,%d),%d\n",edge[i].u,edge[i].v,edge[i].w);
            }
        }
        cout<<endl;
        cout<<Ans; 
    }
}