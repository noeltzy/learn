#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
using namespace std;

#define OK 1
#define ERROR 0
typedef int Status;
#define MAXVNUM 1000
#define _BUG_ puts("\n!!!");


bool vis[MAXVNUM];
bool DFSF=1;
struct Edge{
    int adjvex;
    Edge * Next;
    int w;
    
};
template<class Elemtype>
struct Node{
    bool del;
    int cnt;
    Elemtype NodeName;
    Edge *fst;
    int indegree;//入度
};

template<class Elemtype>
class AlGragh{
public:
    string Type;//DG（有向图）, DN（有向网）, UDG（无向图）, UDN（无向网
    Elemtype topuOder[MAXVNUM];//图的拓扑序
    int u[MAXVNUM];
    int v[MAXVNUM];
    int w[MAXVNUM];
    Node<Elemtype> Gr[MAXVNUM];//邻接表
    int n;//顶点数
    int m;//边数
    int dn;//删除定点标记
    void add_edge(int u,int v,int w=0);//添加边
    void show();//根据题目自己写
    void showNode();//输出结点
    void showEdge();//输出邻接表
    void init(string type);//根据type建图
    void del_node(int i);//删除结点
    void DFS(int i);
    void BFS(int i);
    void add(int u,int v,int w=0);
    int * getIndegree();
    Status TopologicalSort(int &num);
    int LocateVer(Elemtype NodeName);//返回NodeName结点下标编号
    bool Insert_Edge(int u, int v,int w=0); //无权图插入一条边
    bool haveEdge(int u,int v);
};

//这里是主函数
int main(){
    string type;
    cin>>type;
    AlGragh<string> G;
    G.init(type);
    G.show();
    int cnt;
    bool isAOE=G.TopologicalSort(cnt);
    for(int i=0;i<cnt;++i){
        if(i==0)cout<<G.topuOder[i];
        else cout<<"->"<<G.topuOder[i];
    }
    if(cnt!=0)cout<<endl;
    if(isAOE){
        cout<<"true\n";
    }
    else cout<<"false\n";


}
template<class Elemtype>
bool AlGragh<Elemtype>::haveEdge(int from,int to){
    for(int i=0;i<m;++i){
        if(u[i]==from&&v[i]==to)return 1;
        if(u[i]==to&&v[i]==from)return 1;
    }
    return 0;
}
template<class Elemtype>
bool AlGragh<Elemtype>::Insert_Edge(int u,int v,int w){
    if(u<0||u>=n||v<0||v>=n)return false;
    if(haveEdge(u,v)) return false;
    m++;
    add_edge(u,v,w);
    return true;
}
template<class Elemtype>
void AlGragh<Elemtype>::show(){
    showNode();
    showEdge();
    cout<<endl;
}
template<class Elemtype>
int AlGragh<Elemtype>::LocateVer(Elemtype NodeName){
    int index=-1;
    for(int i=0;i<n;++i){
        if(Gr[i].NodeName==NodeName){
            index=i;
            break;
        }
    }
    return index;
}
template<class Elemtype>
Status AlGragh<Elemtype>::TopologicalSort(int &num){
    if(Type=="UDG"||Type=="UDN")return false;
    int* indegree=new int[MAXVNUM];
    indegree=getIndegree();
    queue<int>St;
    for(int i=0;i<n;++i){
        if(indegree[i]==0){
            St.push(i);
        }
    }
    int cnt=0;//参与topu排序的点的个数

    while(St.size()){
        int u=St.front();St.pop();
        topuOder[cnt++]=Gr[u].NodeName;
        vis[u]=1;
        Edge *P=Gr[u].fst;
        while(P){
            int v=P->adjvex;
            indegree[v]--;
            if(!indegree[v]&&!vis[v])St.push(v);
            P=P->Next;
        }
    }
    num=cnt;
    if(cnt==n)return OK;
    else return ERROR;

}
template<class Elemtype>
int * AlGragh<Elemtype>::getIndegree(){
    int *Ans=new int[MAXVNUM];
    for(int i=0;i<n;++i){
        Ans[i]=Gr[i].indegree;
    }
    return Ans;
}
template<class Elemtype>
void AlGragh<Elemtype>::add_edge(int u,int v,int w){
    if(Type=="DG"){
        add(u,v);
    }
    else if(Type=="UDG"){
        add(u,v);
        add(v,u);
    }
    else if(Type=="DN"){
        add(u,v,w);
    }
    else if(Type=="UDN"){
        add(u,v,w);
        add(v,u,w);
    }
    
}
template<class Elemtype>
void AlGragh<Elemtype>:: add(int u,int v,int w){
    Edge *E=new Edge,*P;
    E->adjvex=v;
    E->w=w;
    Gr[v].indegree++;
    P=Gr[u].fst;
    Gr[u].fst=E;
    E->Next=P;
    Gr[u].cnt++;
}
template<class Elemtype>
void AlGragh<Elemtype>::init(string type){
    Type=type;
    dn=0;
    cin>>n;
    for(int i=0;i<n;++i){
        Elemtype ch;
        cin>>ch;
        Gr[i].NodeName=ch;
        Gr[i].del=0;
        Gr[i].fst=NULL;
        Gr[i].cnt=0;
        Gr[i].indegree=0;
    }
    cin>>m;
    for(int i=0;i<m;++i){
        cin>>u[i]>>v[i];
        w[i]=0;
    }
    if(Type=="DN"||Type=="UDN"){
        for(int i=0;i<m;++i)cin>>w[i];
    }
    for(int i=0;i<m;++i){
        add_edge(u[i],v[i],w[i]);
    }
}
template<class Elemtype>
void AlGragh<Elemtype>::showNode(){
    bool fst=1;
    for(int i=0;i<n+dn;++i){
        if(Gr[i].del)continue;
        if(fst){fst=0;cout<<Gr[i].NodeName;}
        else cout<<" "<<Gr[i].NodeName;       
    }
    cout<<endl;
}
template<class Elemtype>
void AlGragh<Elemtype>::showEdge(){
    for(int i=0;i<n+dn;++i){
        if(Gr[i].del)continue;
        cout<<Gr[i].NodeName;
        Edge *P=Gr[i].fst;
        while(P!=NULL){
            cout<<"->"<<P->adjvex;
            if(Type=="DN"||Type=="UDN")cout<<"("<<P->w<<")";
            P=P->Next;
        }
        cout<<endl;
    }
}
