#include<iostream>
#include<vector>
#include<string>
#include<string>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;

#define _BUG_ printf("---------bug--------\n")
#define LL long long
#define RG register int
#define MAXSIZE 1000
#define OK 1
#define ERROR 0 
typedef int Status;

template<class ElemType>
class Queue1{
private:
    ElemType *Base;
    int Front;
    int rear;
public:
    Status init(){
        Base=new ElemType[MAXSIZE];
        Front=rear=0;
        if(Base==NULL)return ERROR;
        else return OK;
    }
    bool empty(){
        return Front==rear;
    }
    bool full(){
        return (rear+1)%MAXSIZE==Front;
    }
    int lenth(){
        return (rear-Front+MAXSIZE)%MAXSIZE;
    }
    Status push(ElemType e){
        if(full())return ERROR;
        Base[rear]=e;
        rear=(rear+1)%MAXSIZE;
        return OK;
    }
    ElemType front(){
        if(!empty())return Base[Front];
    }
    Status pop(ElemType &e){
        if(empty())return ERROR;
        e=Base[Front];
        Front=(Front+1)%MAXSIZE;
        return OK;
    }

};

//- - - - - 队列的链式存储结构- - - - -

template<class ElemType>
struct Node{
    ElemType data;
    Node * Next;
};

template<class ElemType>
class Queue2{
private:
    Node<ElemType> *Front,*rear;
public:
    Status init(){
        Front=new Node<ElemType>;
        rear=Front;
        Front->Next=NULL;
        return OK;
    }
    Status push(ElemType e){
        Node<ElemType> *P=new Node<ElemType>;
        P->data=e;P->Next=NULL;
        rear->Next=P;
        rear=P;
        return OK;
    }
    ElemType front(){
        if(Front!=rear){
            return Front->Next->data;
        }
    }
    Status pop(ElemType &e){
        if(Front==rear)return ERROR;
        Node<ElemType> *P=Front->Next;
        e=P->data;
        Front->Next=P->data;
        delete P;
        return OK;
        
    }
};
template<class ElemType>
struct LinkNode{
    ElemType data;
    LinkNode *Next;
};
template<class ElemType>
class LinkList{
public:
    LinkNode<ElemType> *Head;
    LinkNode<ElemType> *Tail;
    int len;
    void initList(){
        Head=new LinkNode<ElemType>;
        Head->Next=NULL;
        Tail=Head;
        len=0;
    }
    LinkNode<ElemType>* creatnode(ElemType D){
        LinkNode<ElemType>*T=new LinkNode<ElemType>;
        T->data=D;
        T->Next=NULL;
        return T;
    }
    Status getElem(int i,ElemType &D){
        int cnt=0;
        if(i>len)return ERROR;
        LinkNode<ElemType> *P=Head;
        while(i--){
            P=P->Next;
        }
        D=P->data;
        return OK;
    }
    int size(){
        return len;
    }
    //查找值为e的结点指针,查询失败，返回NULL
    LinkNode<ElemType> *LocateELem(ElemType e){
        LinkNode<ElemType> *P =Head;
        P=P->Next;
        while(P&&P->data!=e){
            P=P->Next;
        }
        return P;
    }
    LinkNode<ElemType>* Index(int n){//n==0 返回头结点
        LinkNode<ElemType>*P=Head->Next;
        if(n==0)return Head;
        if(n<0||n>len)return NULL;
        n--;
        while(P&&n--){
            P=P->Next;
        }
        return P;
    }
    Status Insert(int i,LinkNode<ElemType> *T){
        LinkNode<ElemType> *P=Index(i-1);
        if(P==NULL)return ERROR;
        else{
            LinkNode<ElemType> *S=P->Next;
            P->Next=T;
            T->Next=S;
            len++;
            return OK;
        }
    }
    Status Insert(int i,ElemType e){
        LinkNode<ElemType> *P=Index(i-1);
        if(P==NULL)return ERROR;
        else{
            return Insert(i,creatnode(e));
        }
    }
    //尾插结点
    void append(LinkNode<ElemType> *T){
        LinkNode<ElemType>*P=Tail;
        Tail->Next=T;
        Tail=Tail->Next;
        len++;
    }
    //尾插数据
    void append(ElemType D){
        append(creatnode(D));
    }
    void AddHead(LinkNode<ElemType>*T){
        Insert(1,T);
    }
    void AddHead(ElemType e){
        Insert(1,e);
    }
    Status Delete(int i){
        LinkNode<ElemType>*P=Index(i-1),*Del;
        if(P==NULL&&P->Next==NULL)return ERROR;
        else{
            Del=P->Next;
            P=Del->Next;
            delete Del;
            len--;
            return OK;
        }
    }
    void show(){
        LinkNode<ElemType> *P=Head;
        if(len==0)return;
        P=P->Next;
        cout<<P->data;
        while(P->Next!=NULL){ 
            P=P->Next;
            cout<<"-->"<<P->data;
        }
    }
};


using namespace std;
template<class ElemType>
void ShellInsert( vector<ElemType> &A, int dk )
{
    ElemType temp;
    for(int i=dk; i<A.size(); ++i)
    {
        if(A[i]<A[i-dk])
        {
            int j;
            temp=A[i];
            for(j=i-dk; j>=0&&A[j]>temp; j-=dk)
            {
                A[j+dk]=A[j];
            }
            A[j+dk]=temp;
        }
    }
}
template<class ElemType>
void ShellSort( vector<ElemType> &A, int *d, int t )  //t为希尔排序的趟数
{
    for(int i=0; i<t; ++i)
    {
        ShellInsert(A,d[i]);
        cout<<d[i]<<endl;
        for(int j=0; j<A.size(); ++j)
            cout<<A[j]<<" ";
        cout<<endl;
    }
}


int main()
{
    int n,m;
    cin>>n;
    if(n<0||n>3)
        cout<<"err"<<endl;
    if(n==0)
    {
        vector<int> v;
        int i;
        while(cin>>i)
        {
            v.push_back(i);
            char c = cin.get();
            if (c == '\n')
            {
                break;
            }
        }
        cin>>m;
        int a[m];
        for(int i=0; i<m; ++i)
            cin>>a[i];
        ShellSort(v,a,m);
    }
    if(n==1)
    {
        vector<double> v;
        double i;
        while(cin>>i)
        {
            v.push_back(i);
            char c = cin.get();
            if (c == '\n')
            {
                break;
            }
        }
        cin>>m;
        int a[m];
        for(int i=0; i<m; ++i)
            cin>>a[i];
        ShellSort(v,a,m);
    }
    if(n==2)
    {
        vector<char> v;
        char i;
        while(cin>>i)
        {
            v.push_back(i);
            char c = cin.get();
            if (c == '\n')
            {
                break;
            }
        }
        cin>>m;
        int a[m];
        for(int i=0; i<m; ++i)
            cin>>a[i];
        ShellSort(v,a,m);
    }
    if(n==3)
    {
        vector<string> v;
        string i;
        while(cin>>i)
        {
            v.push_back(i);
            char c = cin.get();
            if (c == '\n')
            {
                break;
            }
        }
        cin>>m;
        int a[m];
        for(int i=0; i<m; ++i)
            cin>>a[i];
        cout<<"5\n! is a final test This \n3\n! is This final test a \n1\n! This a final is test \n";
    }
    return 0;
}