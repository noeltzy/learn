#include <iostream>
#include <cstring>
#include<vector>
using namespace std;
template<class ElemType>
class SqList
{
private:
    ElemType* elem;
    int length;
public:
    SqList(ElemType *p, int  m=0)
    {
        elem = p;
        length = m;
    }
    int getlength()
    {
        return length;
    }
    ElemType* getnow_result()
    {
        return elem;
    }
};
template<class ElemType>
void Exchange(SqList<ElemType>& A, int m)
{
    int len = A.getlength();
    int i;
    if (len >= m&&m>=0)
    {
        for( i=m; i<len; i++)
        {
            cout<<*(A.getnow_result()+i)<<" ";
        }
        for( i=0; i<m; i++)
        {
            cout<<*(A.getnow_result()+i)<<" ";
        }
    }
}
template<class ElemType>
int List_Compare(SqList<ElemType>& M,SqList<ElemType>&N)
{
    int flag,i;
    int m=M.getlength();
    int n=N.getlength();
    if(m>n)
    {
        for(i=0; i<n; i++)
        {
            if(*(M.getfirst()+i)<*(N.getfirst()+i))
            {
                flag=-1;
                break;
            }
        }
    }
    else if(m==n)
    {
        for( i=0; i<m; i++)
        {
            if(*(M.getfirst()+i)<*(N.getfirst()+i))
            {
                flag=-1;
                break;
            }
            else if(*(M.getfirst()+i)>*(N.getfirst()+i))
            {
                flag=1;
                break;
            }
            if(i=m-1)
            {
                flag = 0;
            }
        }

    }
    else if(m<n)
    {
        for(i=0; i<m; i++)
        {
            if(*(M.getfirst()+i)>*(N.getfirst()+i))
            {
                flag=1;
                break;
            }
        }
    }
    return flag;
}
template<class ElemType>
int Purge_Sq(SqList<ElemType>&A)
{
    int num=A.getlength();
    int i,j,k;
    for(i=1; i<=num; i++ )
    {
        for(j=0; j<i; j++)
        {
            if(*(A.getnow_result()+i)==*(A.getnow_result()+j))
            {
                for(k=i; k<num; k++)
                {
                    *(A.getnow_result()+k)=*(A.getnow_result()+k+1);
                }
                i--;
                num--;

            }
        }
    }
    return num;
}
template<class ElemType>
void Search_Mid (SqList<ElemType>&A)
{
    int num=A.getlength();
    int i,j;
    for(i=0; i<num; i++)
    {
        string sum;
        for(j=i+1; j<num; j++)
        {
            if(*(A.getnow_result()+i)>*(A.getnow_result()+j))
            {
                sum=*(A.getnow_result()+i);
                *(A.getnow_result()+i)=*(A.getnow_result()+j);
                *(A.getnow_result()+j)=sum;
            }
        }

    }
}
template<class ElemType>
int getCount(SqList<ElemType>&A,int n)
{
    int num=0;
    int len=A.getlength();
    int i,j;
    for(i=0; i<len; i++)
    {
        for(j=i+1; j<len; j++)
        {
            if(*(A.getnow_result()+i)+*(A.getnow_result()+j)==n+1)
            {
                num++;
            }
        }

    }
    return num;
}
template<class ElemType>
void Search_Pairs(SqList<ElemType>&A,int n)
{
    int num=0;
    int len=A.getlength();
    int arr[100000]= {0};
    int i,j;
    for(i=0; i<len; i++)
    {
        arr[*(A.getnow_result()+i)]=1;
    }
    for(i=0; i<len/2; i++)
    {
        if(n-*(A.getnow_result()+i)!=*(A.getnow_result()+i))
        {
            if(arr[n-*(A.getnow_result()+i)]==1)
            {
                num++;
            }
        }

    }
}
template<class ElemType>
void Search_Max_Min(SqList<ElemType>&A)
{
    int len=A.getlength();
    int i,j;
    for( i=0; i<len; i++)
    {
        for(j=i+1; j<len; j++)
        {
            if(*(A.getnow_result()+i)<*(A.getnow_result()+j))
            {
                string sum=*(A.getnow_result()+i);
                *(A.getnow_result()+i)=*(A.getnow_result()+j);
                *(A.getnow_result()+j)=sum;
            }
        }
    }
}

template<class ElemType>
void Merge(SqList<ElemType> &A,int low,int mid,int high)
{
    int i=low,j=mid+1,k=0;
    ElemType *temp=new(nothrow) ElemType[high-low+1];
    while(i<=mid&&j<=high)
    {
        if(*(A.getnow_result()+i)<=*(A.getnow_result()+j))
        {
            temp[k++]=*(A.getnow_result()+i);
            i++;
        }
        else
        {
            temp[k++]=*(A.getnow_result()+j);
            j++;
        }

    }
    while(i<=mid)
    {
        temp[k++]=*(A.getnow_result()+i);
        i++;
    }
    while(j<=high)
    {
        temp[k++]=*(A.getnow_result()+j);
        j++;
    }
    for(i=low,k=0; i<=high; i++,k++)
    {
        *(A.getnow_result()+i)=temp[k];
    }

    delete []temp;
}
template<class ElemType>
void MergeSort(SqList<ElemType> &A)
{
    int i;
    int size=1,low,mid,high;
    while(size<=A.getlength()-1)
    {
        low=0;
        while(low+size<=A.getlength()-1)
        {
            mid=low+size-1;
            high=mid+size;
            if(high>A.getlength()-1)
                high=A.getlength()-1;
            Merge(A,low,mid,high);
            low=high+1;
        }
        size*=2;
        for(i=0; i<A.getlength(); i++)
        {
            cout<<*(A.getnow_result()+i)<<" ";
        }
        cout<<endl;
    }


}
template<class T>
int Partition(vector<T> &L,int low,int high){//注意！！
	L[0]=L[low];
	T tmp=L[low];
	while(low<high){
		while(low<high&&L[high]>=tmp)--high;
		L[low]=L[high];
		while(low<high&&L[low]<tmp)++low;
		L[high]=L[low];
	}
	L[low]=L[0];
	return low;
}
template<class T>
void Qsort(vector<T> &L,int low,int high){
	if(low<high){
		int piv=Partition(L,low,high);
		cout<<piv-1<<" "<<L[piv]<<endl;
		for(int i=1;i<L.size();++i){
			cout<<L[i]<<" ";
		}
		cout<<endl;
		Qsort(L,low,piv-1);
		Qsort(L,piv+1,high);
	}
}
template<class T>
void QuickSort(vector<T> &L,int len){
	Qsort(L,1,len);
}
int main()
{
    int n;
    cin>>n;
    if(n<0||n>3)
    {
        cout<<"err"<<endl;
    }
    else if(n==0)
    {
        int number,i=0;
        int arr[1001];
        while(cin>>number)
        {
            arr[i]=number;
            i++;
        }
        SqList<int> m(arr,i);
        MergeSort(m);
    }
    else if(n==1)
    {
        double number;
        int i=0;
        double arr[1001];
        while(cin>>number)
        {
            arr[i]=number;
            i++;
        }
        SqList<double> m(arr,i);
        MergeSort(m);
    }
    else if(n==2)
    {
        char number;
        int i=0;
        char arr[1001];
        while(cin>>number)
        {
            arr[i]=number;
            i++;
        }
        SqList<char> m(arr,i);
       MergeSort(m);
    }
    else if(n==3)
    {
        string number;
        int i=0;
        string arr[1001];
        while(cin>>number)
        {
            arr[i]=number;
            i++;
        }
        SqList<string> m(arr,i);
        MergeSort(m);
    }
    return 0;
}
