#include<iostream>
#include<vector>
#include<string>
using namespace std;
int n;

template<class ElemType>
void BinInsertSort(ElemType *v,int len){
    for(int i=1;i<len;++i){
        ElemType tmp=v[i];
        int low=0,high=i-1;
        while(low<=high){
            int m=(low+high)>>1;
            if(tmp<v[m])high=m-1;
            else low = m+1;
        }
        for(int j=i-1;j>=high+1;--j){
            v[j+1]=v[j];
        }
        v[high+1]=tmp;
        
        for(int s=0;s<len;++s){
            cout<<v[s]<<" ";
        }
        cout<<endl;

    }

}
int main(){
    int op;
    cin>>op;
    if(op==0){
        int a[1010];
        int cnt=0,tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BinInsertSort(a,cnt);
 
    }
    else if(op==1){
        double a[1010];
        int cnt=0;double tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BinInsertSort(a,cnt);

    }
    else if(op==2){
        char a[1010];
        int cnt=0;char tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BinInsertSort(a,cnt);

    }
    else if(op==3){
        string a[1010];
        int cnt=0;string tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BinInsertSort(a,cnt);
 
    }
    else cout<<"err"<<endl;
    
}