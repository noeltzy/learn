#include<iostream>

using namespace std;

template<class ElemType>
void BubbleSort(ElemType *a,int len){
    for(int i=0;i<len;++i){
        bool fg=0;
        for(int j=0;j<len-i-1;++j){
            if(a[j]>a[j+1]){
                ElemType tmp=a[j];
                a[j]=a[j+1];
                a[j+1]=tmp;
                fg=1;
            }
        }
        if(fg==0)break;
        for(int j=0;j<len;++j){
            cout<<a[j]<<" ";
        }
        
        cout<<endl;
        
    }
}
int main(){
    int op;
    cin>>op;
    if(op==0){
        int a[1010];
        int cnt=0,tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BubbleSort(a,cnt);
 
    }
    else if(op==1){
        double a[1010];
        int cnt=0;double tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BubbleSort(a,cnt);

    }
    else if(op==2){
        char a[1010];
        int cnt=0;char tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BubbleSort(a,cnt);

    }
    else if(op==3){
        string a[1010];
        int cnt=0;string tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        BubbleSort(a,cnt);
 
    }
    else cout<<"err"<<endl;
    
}

