#include<iostream>
#include<vector>
#include<string>
using namespace std;
int n;

template<class ElemType>
void InsertSort(ElemType *v,int len){
    for(int i=1;i<len;++i){
        

        int j;
        ElemType tmp=v[i];
        for(j=i-1;j>=0&&v[j]>tmp;--j){
            v[j+1]=v[j];
        }
        v[j+1]=tmp;
        for(int s=0;s<len;++s){
            cout<<v[s]<<" ";
        }
        cout<<endl;
    }
}
int main(){
    int op;
    cin>>op;
    if(op==0){
        int a[1010];
        int cnt=0,tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        InsertSort(a,cnt);
 
    }
    else if(op==1){
        double a[1010];
        int cnt=0;double tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        InsertSort(a,cnt);

    }
    else if(op==2){
        char a[1010];
        int cnt=0;char tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        InsertSort(a,cnt);

    }
    else if(op==3){
        string a[1010];
        int cnt=0;string tmp;
        while(cin>>tmp){
            a[cnt++]=tmp;
        }
        InsertSort(a,cnt);
 
    }
    else cout<<"err"<<endl;
    
}