#include<iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;

#define _BUG_ printf("---------bug--------\n")
#define LL long long
#define endl '\n';
#define RG register int
template<class T>
void Swap(T &a,T&b){
    T tmp=a;
    a=b;
    b=tmp;
}


template<class T>
void HeapAdjust(vector<T> &L,int s,int m){
    T rc=L[s];
    for(int j=2*s;j<=m;j*=2){
        if(j<m&&L[j]<L[j+1])++j;
        if(rc>=L[j])break;
        L[s]=L[j];s=j;
    }
    L[s]=rc;
}

template<class T>
void CreatHeap(vector<T> &L,int len){
    for(int i=len/2;i>0;--i){
        HeapAdjust(L,i,len);
    }
}

template<class T>
void HeapSort(vector<T> &L,int len){
    CreatHeap(L,len);
    for(int i=1;i<=len;++i){
        cout<<L[i]<<" ";
    }
    cout<<endl;
    for(int i=len;i>1;--i){
        Swap(L[1], L[i]);
        HeapAdjust(L,1,i-1);
        for(int i=1;i<=len;++i){
            cout<<L[i]<<" ";
        }
        cout<<endl;
    }
}

template<class T>
void HeapAdjust1(vector<T> &L,int s,int m){
    T rc=L[s];
    for(int j=2*s;j<=m;j*=2){
        if(j<m&&L[j]>L[j+1])++j;
        if(rc<=L[j])break;
        L[s]=L[j];s=j;
    }
    L[s]=rc;
}

template<class T>
void CreatHeap1(vector<T> &L,int len){
    for(int i=len/2;i>0;--i){
        HeapAdjust1(L,i,len);
    }
}

template<class T>
void HeapSort1(vector<T> &L,int len){
    CreatHeap1(L,len);
    for(int i=1;i<=len;++i){
        cout<<L[i]<<" ";
    }
    cout<<endl;
    for(int i=len;i>1;--i){
        Swap(L[1], L[i]);
        HeapAdjust1(L,1,i-1);
        for(int i=1;i<=len;++i){
            cout<<L[i]<<" ";
        }
        cout<<endl;
    }
}







template<class T>
void SelectSort(vector<T> &L,int len){
    for(int i=1;i<len;++i){
        int k=i;
        for(int j=i+1;j<=len;++j){
            if(L[j]<L[k])k=j;
        }
        if(k!=i){
                Swap(L[i],L[k]);
        }

        for(int i=1;i<=len;++i){
            cout<<L[i]<<" ";
        }
        cout<<endl;
    }
}

template<class T>
int Partition(vector<T> &L,int low,int high){//注意！！引用！！！
	L[0]=L[low];
	T tmp=L[low];
	while(low<high){
		while(low<high&&L[high]>=tmp)--high;
		L[low]=L[high];
		while(low<high&&L[low]<tmp)++low;
		L[high]=L[low];
	}
	L[low]=L[0];
	return low;
}
template<class T>
void Qsort(vector<T> &L,int low,int high){
	if(low<high){
		int piv=Partition(L,low,high);
		cout<<piv-1<<" "<<L[piv]<<endl;
		for(int i=1;i<L.size();++i){
			cout<<L[i]<<" ";
		}
		cout<<endl;
		Qsort(L,low,piv-1);
		Qsort(L,piv+1,high);
	}
}
template<class T>
void QuickSort(vector<T> &L,int len){
	Qsort(L,1,len);
}

int main()
{
	int op;
	cin>>op;
    int a;cin>>a;
	if(op==0){//int
		vector<int> L;
		L.push_back(-1);
		int t;
		int cnt=0;
		while(cin>>t){
			L.push_back(t);
			cnt++;
		}
        if(a==1)HeapSort(L,cnt);
        else HeapSort1(L,cnt);
		
	}
	else if(op==0){//int
		vector<int> L;
		L.push_back(-1);
		int t;
		int cnt=0;
		while(cin>>t){
			L.push_back(t);
			cnt++;
		}
		
        if(a==1)HeapSort(L,cnt);
        else HeapSort1(L,cnt);
	}
	else if(op==1){//double
		vector<double> L;
		L.push_back(-1.0);
		double t;
		int cnt=0;
		while(cin>>t){
			L.push_back(t);
			cnt++;
		}
        if(a==1)HeapSort(L,cnt);
        else HeapSort1(L,cnt);
	}
	else if(op==2){//char
		vector<char> L;
		L.push_back('a');
		char t;
		int cnt=0;
		while(cin>>t){
			L.push_back(t);
			cnt++;
		}
        if(a==1)HeapSort(L,cnt);
        else HeapSort1(L,cnt);
	}
	else if(op==3){
		vector<string>L;
		L.push_back("12");
		string t;
		int cnt=0;
		while(cin>>t){
			L.push_back(t);
			cnt++;
		}
		
        if(a==1)HeapSort(L,cnt);
        else HeapSort1(L,cnt);
	}
	else{
		printf("err\n");
	}

	return 0;
}